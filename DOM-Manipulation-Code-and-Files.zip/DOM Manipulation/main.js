//DOM MANIPULATION
/*
//1. SELECTING DOM ELEMENTS
let showResult=document;

showResult=document.body;
showResult=document.head;

//old way
showResult=document.getElementById('logo')
showResult=document.getElementsByClassName('course-status')
showResult=document.getElementsByClassName('left')
showResult=document.getElementsByTagName('div');


// new way
showResult=document.querySelector('section')
showResult=document.querySelectorAll('section')


showResult=document.querySelector('.category')
showResult=document.querySelector('#logo')
showResult=document.querySelectorAll('.category')
console.log(showResult)

*/


//2. CHANGING CONTENT 

// changing text 
const logo = document.querySelector("#logo")
// console.log(logo)

const logoText = logo.querySelector('h1')
// logoText.textContent="Iftiinshe"
// logoText.innerText="Iftiinshe"
logoText.innerHTML="IFTIINSHE"



const webDevCategory = document.querySelector('.category')
webDevCategory.textContent="Development"



//changing attribute values

const jsImage = document.querySelector('img')
jsImage.src="./images/image-4.png"
jsImage.alt="This is javaScript"



//3. CHANGING STYLES USING JS

logoText.style.color="Brown";


const categoryTitle = document.querySelectorAll('.category')
// console.log(categoryTitle)

for (const category of categoryTitle) {
    category.style.backgroundColor="Brown"
    
}


//4. CREATING NEW HTML ATTRIBUTE 

const image2=document.querySelectorAll('img')[1]
image2.setAttribute('title', 'Image About MySQL')

const newCoursesTitle = document.querySelectorAll('h1')[1]
newCoursesTitle.setAttribute('style', 'font-style: italic; color: darkOrange')



//5. Events

function changeLogoText(){
    logoText.innerText="Korodhso Aqoon"
}


// event listeners
/*
const enrollBtn = document.querySelector('.enroll-btn');
enrollBtn.addEventListener('click', enrolled);

function enrolled(){
    enrollBtn.style.backgroundColor="Green";
    enrollBtn.style.color="white";
    enrollBtn.textContent="Continue learning..."
}
*/


const enrollBtns = document.querySelectorAll('.enroll-btn')
for (const enrollBtn of enrollBtns) {
    enrollBtn.addEventListener('click', ()=>{
        enrollBtn.style.backgroundColor="Green";
    enrollBtn.style.color="white";
    enrollBtn.textContent="Continue learning..."
    })
}


//6. CLASSLIST (add, remove, toggle), CLASSNAME
const sections = document.querySelectorAll('section')
//add remove
for (const section of sections) {
    section.addEventListener('mouseover', ()=>{
        section.className='section-style2'
    })

    section.addEventListener('mouseleave',()=>{
        section.classList.remove('section-style2')
    })
    
}





//toggle
const categoryTitle1 = document.querySelector('.category'),
        section1=document.querySelector('section');

        categoryTitle1.addEventListener('click',()=>{
            section1.classList.toggle('button-style2')
        })


// 7. CREATING NEW HTML ELEMENTS
const newButton = document.createElement('button')
newButton.innerText="About US";
newButton.className="about-btn"
// console.log(newButton)


//adding item to the footer

const footer = document.querySelector('footer');
footer.append(newButton)

//styling footer
footer.style.direction="flex"
footer.style.flexFlow="column-reverse"
newButton.style.padding="5px"
newButton.style.marginBottom="2px"


//NAVIGATING BETWEEN ELEMENTS
//parentNode, childNode, firstChild, lastChild, nextSibling, previousSibling)

const menu = document.querySelector('nav')
// console.log(menu)

//parent 
// const parentOfMenu= menu.parentElement
// console.log(parentOfMenu)

// const allMenuChilds=menu.children
// console.log(allMenuChilds)


// //first child
// const firstChild = menu.firstElementChild
// console.log(firstChild)

// //last child
// const lastChild = menu.lastElementChild;
// console.log(lastChild)


// //next sibling

// const nextChild = firstChild.nextElementSibling;
// console.log(nextChild)

// const previousSibling = lastChild.previousElementSibling
// console.log(previousSibling)